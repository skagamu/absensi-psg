// SCRIPT GENERATOR DUMMY DATA UNTUK UJI COBA
// Buka Google Apps Script Anda, buat file baru (misalnya "GenerateDummy.gs"),
// paste kode ini, lalu klik tombol "Jalankan" (Run) di menu atas.

function generateDummyData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // 1. Setup Pembimbing
  let sheetPembimbing = ss.getSheetByName("Pembimbing");
  if (!sheetPembimbing) sheetPembimbing = ss.insertSheet("Pembimbing");
  sheetPembimbing.clear();
  sheetPembimbing.appendRow(["ID", "Nama", "Secret"]);
  sheetPembimbing.appendRow(["1", "Budi Santoso", "adadeh"]);
  sheetPembimbing.appendRow(["2", "Siti Aminah", "rahasia"]);
  
  // 2. Setup Siswa
  let sheetSiswa = ss.getSheetByName("Siswa");
  if (!sheetSiswa) sheetSiswa = ss.insertSheet("Siswa");
  sheetSiswa.clear();
  sheetSiswa.appendRow(["NISN", "Nama", "Kelas", "Nama Pembimbing", "Lokasi PKL", "Kontak", "Tanggal Lahir"]);
  sheetSiswa.appendRow(["1001", "Andi Syaputra", "11 RPL", "Budi Santoso", "PT. Teknologi", "0811", "01/01/2005"]);
  sheetSiswa.appendRow(["1002", "Bagas Pratama", "11 RPL", "Budi Santoso", "PT. Teknologi", "0812", "02/02/2005"]);
  sheetSiswa.appendRow(["1003", "Citra Lestari", "11 RPL", "Budi Santoso", "PT. Inovasi", "0813", "03/03/2005"]);
  sheetSiswa.appendRow(["2001", "Dedi Supardi", "11 TKJ", "Siti Aminah", "PT. Jaringan", "0814", "04/04/2005"]);
  
  // 3. Setup Pengaturan
  let sheetPengaturan = ss.getSheetByName("Pengaturan");
  if (!sheetPengaturan) sheetPengaturan = ss.insertSheet("Pengaturan");
  sheetPengaturan.clear();
  sheetPengaturan.appendRow(["Tgl_Mulai", "Tgl_Selesai", "Hari_Libur"]);
  sheetPengaturan.appendRow(["01/04/2026", "31/05/2026", "01/05/2026, 09/05/2026, 14/05/2026"]); 
  
  // 4. Setup Absensi
  let sheetAbsensi = ss.getSheetByName("Absensi");
  if (!sheetAbsensi) sheetAbsensi = ss.insertSheet("Absensi");
  sheetAbsensi.clear();
  sheetAbsensi.appendRow(["ID", "Tanggal", "Waktu", "NISN", "Latitude", "Longitude", "Status", "Foto", "Alasan"]);
  
  // Rentang 2 Bulan (1 April 2026 - 31 Mei 2026)
  let startDate = new Date(2026, 3, 1); 
  let endDate = new Date(2026, 4, 31); 
  let libur = ["01/05/2026", "09/05/2026", "14/05/2026"];
  
  let students = ["1001", "1002", "1003"];
  let idCounter = 1;
  let rowsToInsert = [];
  
  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    let day = d.getDay();
    if (day === 0 || day === 6) continue; // Lewati Sabtu & Minggu
    
    let tglStr = Utilities.formatDate(d, Session.getScriptTimeZone(), "dd/MM/yyyy");
    if (libur.includes(tglStr)) continue; // Lewati hari libur
    
    // Generate data untuk 3 siswa Budi Santoso
    students.forEach((nisn) => {
      let rand = Math.random();
      let status = "Hadir";
      
      // Simulasi Watak Siswa:
      if (nisn === "1001") {
         // Andi: Sangat rajin (95% Hadir, 5% Sakit, 0% Alpha)
         if (rand > 0.95) status = "Sakit"; 
      } else if (nisn === "1002") {
         // Bagas: Biasa saja (70% Hadir, 10% Izin, 20% Alpha)
         if (rand > 0.8) status = "Izin";
         else if (rand > 0.6) return; // Skip row = Belum Absen / Alpha
      } else {
         // Citra: Jarang masuk (50% Hadir, 10% Sakit, 40% Alpha)
         if (rand > 0.6) return; // Skip row = Belum Absen / Alpha
         else if (rand > 0.5) status = "Sakit";
      }
      
      let jam = "07:" + Math.floor(Math.random() * 59).toString().padStart(2, '0');
      let lat = "-6.20" + Math.floor(Math.random() * 1000);
      let lng = "106.81" + Math.floor(Math.random() * 1000);
      let alasan = (status === "Sakit" || status === "Izin") ? "Keterangan dari ortu" : "";
      
      rowsToInsert.push([
        "DUMMY-" + idCounter++, 
        tglStr, 
        jam, 
        nisn, 
        lat, 
        lng, 
        status, 
        "https://dummyimage.com/120x120/1e3a8a/ffffff&text=" + status, // Foto dummy
        alasan
      ]);
    });
  }
  
  // Masukkan semua baris sekaligus ke Google Sheets agar cepat
  if (rowsToInsert.length > 0) {
    sheetAbsensi.getRange(2, 1, rowsToInsert.length, 9).setValues(rowsToInsert);
  }
  
  Logger.log("Berhasil membuat " + rowsToInsert.length + " data absensi dummy!");
}
