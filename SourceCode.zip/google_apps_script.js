const FOLDER_ID = "1nCq62V2rZ8GkC7jM3yYj1k_XhG-fO4fU"; 

function doPost(e) {
  try {
    if (!e.postData) {
      throw new Error("Tidak ada data POST yang diterima.");
    }
    
    let data;
    try {
      data = JSON.parse(e.postData.contents);
    } catch (err) {
      throw new Error("Format JSON salah");
    }

    // --- LOGIC LOGIN SISWA ---
    if (data.action === "login") {
      const sheetSiswa = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Siswa");
      if (!sheetSiswa) throw new Error("Sheet 'Siswa' tidak ditemukan di database.");
      
      const dataSiswa = sheetSiswa.getDataRange().getDisplayValues();
      
      for (let i = 1; i < dataSiswa.length; i++) {
        if (dataSiswa[i][0] == data.nisn) {
          // Asumsi Kolom G (index 6) adalah Tgl Lahir di sheet Siswa
          let tglSheet = String(dataSiswa[i][6]).trim();
          let tglInput = String(data.tglLahir).trim();
          
          let normalize = (str) => {
             let p = str.split(/[\/\-]/);
             if (p.length === 3) return parseInt(p[0]) + "/" + parseInt(p[1]) + "/" + parseInt(p[2]);
             return str;
          };

          if (normalize(tglSheet) === normalize(tglInput)) { 
            return ContentService.createTextOutput(JSON.stringify({
              status: "success",
              message: "Login Berhasil",
              nama: dataSiswa[i][1] // Kolom B adalah Nama
            })).setMimeType(ContentService.MimeType.JSON);
          } else {
            throw new Error("NISN atau Tanggal Lahir tidak cocok.");
          }
        }
      }
      throw new Error("NISN tidak terdaftar di sistem.");
    }

    // --- LOGIC LOGIN GURU ---
    if (data.action === "login_guru") {
      const sheetGuru = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Pembimbing");
      if (!sheetGuru) throw new Error("Sheet 'Pembimbing' tidak ditemukan di database.");
      
      const dataGuru = sheetGuru.getDataRange().getDisplayValues();
      for (let i = 1; i < dataGuru.length; i++) {
        // Asumsi Kolom A (0) = ID, Kolom B (1) = Nama, Kolom C (2) = Secret
        if (dataGuru[i][0] == data.idGuru && dataGuru[i][2] == data.secret) {
          return ContentService.createTextOutput(JSON.stringify({
            status: "success",
            message: "Login Guru Berhasil",
            nama: dataGuru[i][1]
          })).setMimeType(ContentService.MimeType.JSON);
        }
      }
      throw new Error("ID Pembimbing atau Kata Sandi salah.");
    }

    // --- LOGIC SIMPAN ABSENSI ---
    if (data.action === "absen") {
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Absensi");

      const tanggalSekarang = Utilities.formatDate(new Date(), "Asia/Jakarta", "dd/MM/yyyy");
      const waktuSekarang = Utilities.formatDate(new Date(), "Asia/Jakarta", "HH:mm:ss");

      // Validasi 1 Kali Sehari
      const dataAbsensi = sheet.getDataRange().getDisplayValues();
      for (let i = dataAbsensi.length - 1; i >= 1; i--) {
        if (dataAbsensi[i][3] == data.nisn && dataAbsensi[i][1] == tanggalSekarang) {
          throw new Error("Anda sudah melakukan absensi hari ini!");
        }
      }

      // Proses foto Base64 ke Google Drive
      let fileUrl = "";
      if (data.photoBase64) {
        let folder = DriveApp.getFolderById(FOLDER_ID);
        let mimeType = data.photoBase64.substring(5, data.photoBase64.indexOf(';'));
        let base64Data = data.photoBase64.split(',')[1];
        let blob = Utilities.newBlob(Utilities.base64Decode(base64Data), mimeType, "Absen_" + data.nisn + "_" + new Date().getTime());
        let file = folder.createFile(blob);
        fileUrl = file.getUrl();
      }

      // Kolom: [ID_Absensi, Tanggal, Waktu, NISN, Latitude, Longitude, Status, Link_Foto, Alasan]
      let rowData = [
        "ABS-" + new Date().getTime(),
        tanggalSekarang,
        waktuSekarang,
        data.nisn,
        data.lat || "",
        data.lng || "",
        data.status,
        fileUrl,
        data.alasan || ""
      ];

      sheet.appendRow(rowData);

      return ContentService.createTextOutput(JSON.stringify({
        status: "success",
        message: "Absensi berhasil dicatat!",
        fileUrl: fileUrl
      })).setMimeType(ContentService.MimeType.JSON);
    }
    
    // Jika tidak ada action yang cocok
    throw new Error("Action POST tidak dikenali: " + data.action);

  } catch (error) {
    // Tangkap semua error dan kirim sebagai JSON
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      message: error.message
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet(e) {
  // CORS Preflight
  if (!e.parameter.action) {
    return ContentService.createTextOutput("API Absensi PKL Aktif.").setMimeType(ContentService.MimeType.JSON);
  }

  // Helper function to read Pengaturan
  function getPengaturan() {
    let setting = { tglMulai: "", tglSelesai: "", libur: [] };
    const sheetPengaturan = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Pengaturan");
    if (sheetPengaturan) {
      const data = sheetPengaturan.getDataRange().getDisplayValues();
      if (data.length > 1) {
        setting.tglMulai = data[1][0] || "";
        setting.tglSelesai = data[1][1] || "";
        let liburStr = data[1][2] || "";
        setting.libur = liburStr.split(',').map(s => s.trim()).filter(s => s.length > 0);
      }
    }
    return setting;
  }

  // --- ENDPOINT UNTUK SISWA MENGAMBIL REKAP ---
  if (e.parameter.action === "getRekap") {
    try {
      const nisn = e.parameter.nisn;
      const bulanParam = e.parameter.bulan || "all";
      const pengaturan = getPengaturan();
      
      const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Absensi");
      const dataAbsensi = sheet ? sheet.getDataRange().getDisplayValues() : [];
      let records = [];
      
      for (let i = dataAbsensi.length - 1; i >= 1; i--) {
        if (dataAbsensi[i][3] == nisn) {
          let tanggalStr = dataAbsensi[i][1];
          let parts = tanggalStr.split('/');
          
          if (bulanParam !== "all" && parts.length === 3) {
            let b = parts[1].replace(/^0+/, '');
            if (b !== bulanParam) continue;
          }

          records.push({
            tanggal: tanggalStr,
            waktu: dataAbsensi[i][2],
            lat: dataAbsensi[i][4],
            lng: dataAbsensi[i][5],
            status: dataAbsensi[i][6],
            foto: dataAbsensi[i][7],
            alasan: dataAbsensi[i][8]
          });
        }
      }

      return ContentService.createTextOutput(JSON.stringify({
        status: "success",
        data: records,
        pengaturan: pengaturan
      })).setMimeType(ContentService.MimeType.JSON);
    } catch (error) {
       return ContentService.createTextOutput(JSON.stringify({
        status: "error",
        message: error.message
      })).setMimeType(ContentService.MimeType.JSON);
    }
  }

  // --- ENDPOINT UNTUK GURU MENGAMBIL REKAP SISWANYA ---
  if (e.parameter.action === "getRekapGuru") {
    try {
      const namaGuru = e.parameter.namaGuru;
      const bulanParam = e.parameter.bulan || "all";
      const pengaturan = getPengaturan();
      
      // 1. Ambil NISN milik siswa bimbingan guru ini
      const sheetSiswa = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Siswa");
      if (!sheetSiswa) throw new Error("Sheet Siswa tidak ada.");
      const dataSiswa = sheetSiswa.getDataRange().getDisplayValues();
      
      let nisnSiswa = [];
      let mapNamaSiswa = {};
      let daftarSiswa = [];
      
      for (let i = 1; i < dataSiswa.length; i++) {
         // Asumsi Kolom D (index 3) adalah Nama Pembimbing, dan Kolom A (0) adalah NISN, B (1) adalah Nama
         let namaGuruDiSheet = String(dataSiswa[i][3]).trim().toLowerCase();
         let namaGuruDicari = String(namaGuru).trim().toLowerCase();
         
         if (namaGuruDiSheet === namaGuruDicari) { 
            nisnSiswa.push(dataSiswa[i][0]);
            mapNamaSiswa[dataSiswa[i][0]] = dataSiswa[i][1];
            daftarSiswa.push({
              nisn: dataSiswa[i][0],
              nama: dataSiswa[i][1]
            });
         }
      }

      // 2. Ambil absen mereka
      const sheetAbsen = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Absensi");
      if (!sheetAbsen) throw new Error("Sheet Absensi tidak ada.");
      const dataAbsensi = sheetAbsen.getDataRange().getDisplayValues();
      let result = [];
      
      for (let i = dataAbsensi.length - 1; i >= 1; i--) {
        let nisn = dataAbsensi[i][3];
        if (nisnSiswa.includes(nisn)) {
          let tanggalStr = dataAbsensi[i][1]; 
          let parts = tanggalStr.split('/');
          let matchBulan = true;
          
          if (bulanParam !== "all" && parts.length === 3) {
            let b = parts[1].replace(/^0+/, '');
            if (b !== bulanParam) matchBulan = false;
          }

          if (matchBulan) {
            result.push({
              nisn: nisn,
              nama: mapNamaSiswa[nisn],
              tanggal: tanggalStr,
              waktu: dataAbsensi[i][2],
              lat: dataAbsensi[i][4],
              lng: dataAbsensi[i][5],
              status: dataAbsensi[i][6],
              foto: dataAbsensi[i][7],
              alasan: dataAbsensi[i][8]
            });
          }
        }
      }
      return ContentService.createTextOutput(JSON.stringify({
        status: "success", 
        data: result,
        siswa: daftarSiswa,
        pengaturan: pengaturan
      })).setMimeType(ContentService.MimeType.JSON);
    } catch(err) {
      return ContentService.createTextOutput(JSON.stringify({
        status: "error", message: err.message
      })).setMimeType(ContentService.MimeType.JSON);
    }
  }

  return ContentService.createTextOutput(JSON.stringify({
    status: "error", message: "Action GET tidak valid"
  })).setMimeType(ContentService.MimeType.JSON);
}
